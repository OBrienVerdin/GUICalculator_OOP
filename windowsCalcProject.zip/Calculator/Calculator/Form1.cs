using System.Globalization;
using System.Numerics;
using System.Runtime.Loader;
using System.Text;
using System.Xml;

//O'Brien Verdin
//GUI Calculator
//Object Oriented Programming 4/5/2023
namespace Calculator
{
    public partial class Form1 : Form
    {
        Solver sv = new Solver();
        string newLine = Environment.NewLine;
        public Form1()
        {
            InitializeComponent();
            textBox1.Font = new Font("Ariel", 18, FontStyle.Bold);
            textBox1.Text = newLine + ("                                                               -----------------");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //When button "1" is pressed
            sv.Accumulate("1");
            textBox1.Text = sv.getText() + newLine + ("                                                               -----------------");

        }
        private void button2_Click(object sender, EventArgs e)
        {
            //When button "2" is pressed
            sv.Accumulate("2");
            textBox1.Text = sv.getText() + newLine + ("                                                               -----------------");
        }
        private void button3_Click(object sender, EventArgs e)
        {
            //When button "3" is pressed
            sv.Accumulate("3");
            textBox1.Text = sv.getText() + newLine + ("                                                               -----------------");
        }
        private void button4_Click(object sender, EventArgs e)
        {
            //When button "4" is pressed
            sv.Accumulate("4");
            textBox1.Text = sv.getText() + newLine + ("                                                               -----------------");
        }
        private void button5_Click(object sender, EventArgs e)
        {
            //When button "5" is pressed
            sv.Accumulate("5");
            textBox1.Text = sv.getText() + newLine + ("                                                               -----------------");
        }
        private void button6_Click(object sender, EventArgs e)
        {
            //When button "6" is pressed
            sv.Accumulate("6");
            textBox1.Text = sv.getText() + newLine + ("                                                               -----------------");
        }
        private void button7_Click(object sender, EventArgs e)
        {
            //When button "7" is pressed
            sv.Accumulate("7");
            textBox1.Text = sv.getText() + newLine + ("                                                               -----------------");
        }
        private void button8_Click(object sender, EventArgs e)
        {
            //When button "8" is pressed
            sv.Accumulate("8");
            textBox1.Text = sv.getText() + newLine + ("                                                               -----------------");
        }
        private void button9_Click(object sender, EventArgs e)
        {
            //When button "9" is pressed
            sv.Accumulate("9");
            textBox1.Text = sv.getText() + newLine + ("                                                               -----------------");
        }
        private void button10_Click(object sender, EventArgs e)
        {
            //This if for when the User clicks on the "0" Button
            sv.Accumulate("0");
            textBox1.Text = sv.getText() + newLine + ("                                                               -----------------");

        }
        private void button11_Click(object sender, EventArgs e)
        {
            //This if for when the User clicks on the "." Button
            sv.Accumulate(".");
            textBox1.Text = sv.getText() + newLine + ("                                                               -----------------");
        }
        private void button12_Click(object sender, EventArgs e)
        {
            //This if for when the User clicks on the "+" Button
            sv.Accumulate("+");
            textBox1.Text = sv.getText() + newLine + ("                                                               -----------------");
        }
        private void button13_Click(object sender, EventArgs e)
        {
            //This if for when the User clicks on the "-" Button
            sv.Accumulate("-");
            textBox1.Text = sv.getText() + newLine + ("                                                               -----------------");
        }
        private void button14_Click(object sender, EventArgs e)
        {
            //This if for when the User clicks on the "/" Button
            sv.Accumulate("/");
            textBox1.Text = sv.getText() + newLine + ("                                                               -----------------");
        }

        private void button15_Click(object sender, EventArgs e)
        {
            //This if for when the User clicks on the "X" Button
            sv.Accumulate("*");
            textBox1.Text = sv.getText() + newLine + ("                                                               -----------------");
        }
        private void button16_Click(object sender, EventArgs e)
        {
            //This if for when the User clicks on the "=" Button
            textBox1.Text = sv.getText() + newLine + ("                                                               -----------------") + newLine + Convert.ToString(sv.Solve());
            
        }

        private void button17_Click(object sender, EventArgs e)
        {
            //This if for when the User clicks on the "A/C" Button
            textBox1.Text = sv.getText() + newLine + ("                                                               -----------------");
            textBox1.Text = sv.getClear() + newLine + ("                                                               -----------------");
        }
        private void button18_Click(object sender, EventArgs e)
        {
            //This is for when the User clicks the "%" Button
            sv.Accumulate("%");
            textBox1.Text = sv.getText() + newLine + ("                                                               -----------------");
        }
        private void button19_Click(object sender, EventArgs e)
        {
            //This if for when the User clicks on the "+/-" Button
            sv.Accumulate("-");
            textBox1.Text = sv.getText() + newLine + ("                                                               -----------------");
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
public interface ISolve
{
    void Accumulate(string s);
    void Clear();
    double Solve();
}

public class Solver : ISolve
{
    string totalText = "";
    public void Accumulate(string s)
    {
        totalText += s;
    }

    public string getText()
    {
        return totalText;
    }

    public void Clear()
    {
        totalText = "";
    }
    public string getClear()
    {
        return totalText = "";
    }

    public double Solve()
    {
        string x1 = "";
        string x2 = "";
        int j, k;
        string temp1 = "";
        string temp2 = "";
        int index1 = 0;
        int index2 = 0;

        //PEMDAS - If Multiplication is found
        for (int i = 0; i < totalText.Length; i++)
        {
            if (totalText[i] == '*')
            {
                index1 = 0;
                index2 = 0;
                //Get number on the right side of the operator
                for (j = i + 1; j < totalText.Length; j++)
                {
                    if (totalText[j] == '+' || totalText[j] == '-' || totalText[j] == '/' || totalText[j] == '*' || totalText[j] == '%')
                    {
                        //Right hand side
                        break;
                    }
                    index1++;
                }
                x1 = totalText.Substring(i + 1, index1);

                //Get number on left side of operator
                for (k = i - 1; 0 <= k; k--)
                {
                    if (totalText[k] == '+' || totalText[k] == '-' || totalText[k] == '/' || totalText[k] == '*' || totalText[k] == '%')
                    {
                        //Left hand side
                        break;
                    }
                    index2++;
                }
                x2 = totalText.Substring(i - index2, index2);

                temp1 = totalText.Substring(0, i - index2);
                temp2 = totalText.Substring(j, totalText.Length - j);

                double a1 = Convert.ToDouble(x1);
                double a2 = Convert.ToDouble(x2);

                double multiplication = a1 * a2;

                string reduce = Convert.ToString(multiplication);

                totalText = temp1 + reduce + temp2;
                i = 0;
            }
        }

        //PEMDAS - If Division is found
        for (int i = 0; i < totalText.Length; i++)
        {
            if (totalText[i] == '/')
            {
                index1 = 0;
                index2 = 0;
                //Get number on the right side of the operator
                for (j = i + 1; j < totalText.Length; j++)
                {
                    if (totalText[j] == '+' || totalText[j] == '-' || totalText[j] == '/' || totalText[j] == '*' || totalText[j] == '%')
                    {
                        //Right hand side
                        break;
                    }
                    index1++;
                }
                x1 = totalText.Substring(i + 1, index1);

                //Get number on left side of operator
                for (k = i - 1; 0 <= k; k--)
                {
                    if (totalText[k] == '+' || totalText[k] == '-' || totalText[k] == '/' || totalText[k] == '*' || totalText[k] == '%')
                    {
                        //Left hand side
                        break;
                    }
                    index2++;
                }
                x2 = totalText.Substring(i - index2, index2);

                temp1 = totalText.Substring(0, i - index2);
                temp2 = totalText.Substring(j, totalText.Length - j);

                double a1 = Convert.ToDouble(x1);
                double a2 = Convert.ToDouble(x2);

                double division = a2/a1;

                string reduce = Convert.ToString(division);

                totalText = temp1 + reduce + temp2;
                i = 0;
            }
        }

        //PEMDAS - If Modular Division is found
        for (int i = 0; i < totalText.Length; i++)
        {
            if (totalText[i] == '%')
            {
                index1 = 0;
                index2 = 0;
                //Get number on the right side of the operator
                for (j = i + 1; j < totalText.Length; j++)
                {
                    if (totalText[j] == '+' || totalText[j] == '-' || totalText[j] == '/' || totalText[j] == '*' || totalText[j] == '%')
                    {
                        //Right hand side
                        break;
                    }
                    index1++;
                }
                x1 = totalText.Substring(i + 1, index1);

                //Get number on left side of operator
                for (k = i - 1; 0 <= k; k--)
                {
                    if (totalText[k] == '+' || totalText[k] == '-' || totalText[k] == '/' || totalText[k] == '*' || totalText[k] == '%')
                    {
                        //Left hand side
                        break;
                    }
                    index2++;
                }
                x2 = totalText.Substring(i - index2, index2);

                temp1 = totalText.Substring(0, i - index2);
                temp2 = totalText.Substring(j, totalText.Length - j);

                double a1 = Convert.ToDouble(x1);
                double a2 = Convert.ToDouble(x2);

                double modDivision = a2 % a1;

                string reduce = Convert.ToString(modDivision);

                totalText = temp1 + reduce + temp2;
                i = 0;
            }
        }

        //PEMDAS - If Addition is found
        for (int i = 0; i < totalText.Length; i++)
        {
            if (totalText[i] == '+')
            {
                index1 = 0;
                index2 = 0;
                //Get number on the right side of the operator
                for (j = i + 1; j < totalText.Length; j++)
                {
                    if (totalText[j] == '+' || totalText[j] == '-' || totalText[j] == '/' || totalText[j] == '*' || totalText[j] == '%')
                    {
                        //Right hand side
                        break;
                    }
                    index1++;
                }
                x1 = totalText.Substring(i + 1, index1);

                //Get number on left side of operator
                for (k = i - 1; 0 <= k; k--)
                {
                    if (totalText[k] == '+' || totalText[k] == '-' || totalText[k] == '/' || totalText[k] == '*' || totalText[k] == '%')
                    {
                        //Left hand side
                        break;
                    }
                    index2++;
                }
                x2 = totalText.Substring(i - index2, index2);

                temp1 = totalText.Substring(0, i - index2);
                temp2 = totalText.Substring(j, totalText.Length - j);

                double a1 = Convert.ToDouble(x1);
                double a2 = Convert.ToDouble(x2);

                double adding = a1 + a2;

                string reduce = Convert.ToString(adding);

                totalText = temp1 + reduce + temp2;
                i = 0;
            }
        }
        //PEMDAS - If Subtraction is found
        for (int i = 0; i < totalText.Length; i++)
        {
            if (totalText[i] == '-')
            {
                index1 = 0;
                index2 = 0;
                //Get number on the right side of the operator
                for (j = i + 1; j < totalText.Length; j++)
                {
                    if (totalText[j] == '+' || totalText[j] == '-' || totalText[j] == '/' || totalText[j] == '*' || totalText[j] == '%')
                    {
                        //Right hand side
                        break;
                    }
                        index1++;
                    }

                    x1 = totalText.Substring(i + 1, index1);

                    //Get number on left side of operator
                    for (k = i - 1; 0 <= k; k--)
                    {
                        if (totalText[k] == '+' || totalText[k] == '-' || totalText[k] == '/' || totalText[k] == '*' || totalText[k] == '%')
                        {
                            //Left hand side
                            break;
                        }
                        index2++;
                    }

                    x2 = totalText.Substring(i - index2, index2);

                    temp1 = totalText.Substring(0, i - index2);
                    temp2 = totalText.Substring(j, totalText.Length - j);

                    double a1 = Convert.ToDouble(x1);
                    double a2 = Convert.ToDouble(x2);

                    double subtraction = a2 - a1;

                    string reduce = Convert.ToString(subtraction);

                    totalText = temp1 + reduce + temp2;
                    i = 0;
                }
            }
        return Convert.ToDouble(totalText);
    }
}